from sys import argv
from sys import exit

print "Add Elements Link to a Box2D API Help Page"

if len(argv) == 1:
	print "- Please specify a .htm file"
	exit(0)

print
print "Checking", argv[1]
f = open(argv[1]).read().strip()
if "< Back to Elements" in f:
	print "- Already added"
else:
	print "- Adding Link"
	f = f.replace('<li><a href="files.htm"><span>Files</span></a></li>', '<li><a href="files.htm"><span>Files</span></a></li>\n\t<li><a href="../"><span>< Back to Elements Doc</span></a></li>')
	
	o = open(argv[1], "w")
	o.write(f)
	o.close()
